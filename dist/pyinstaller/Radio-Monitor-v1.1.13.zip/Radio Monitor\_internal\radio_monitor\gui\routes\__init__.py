"""
GUI Routes Package for Radio Monitor 1.0

This package contains modular route blueprints for the Flask GUI.
Each module handles a specific section of the application.
"""
